package name.modid.mixin;

import name.modid.template.TemplateEnchantments;
import net.minecraft.class_10286;
import net.minecraft.class_1799;
import net.minecraft.class_4862;
import net.minecraft.class_8047;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import java.util.function.Predicate;

@Mixin(class_4862.class)
public abstract class SmithingMenuMixin {
	@Unique
	private static final Predicate<class_1799> ARSA_BASE_PREDICATE = stack ->
		!stack.method_7960() && TemplateEnchantments.isValidBase(stack);

	/**
	 * 原版基底槽只接受 RecipePropertySet 里出现过的物品。
	 * 我们的应用配方基底是“任意非书/非模板物品”，无法用 Ingredient 表达，
	 * 因此在原版槽位定义基础上放宽基底槽（保留原版行为，取并集）。
	 */
	@Inject(method = "createInputSlotDefinitions", at = @At("RETURN"), cancellable = true)
	private static void arsa$widenBaseSlot(class_10286 recipeAccess, CallbackInfoReturnable<class_8047> cir) {
		class_8047 original = cir.getReturnValue();
		class_8047.class_8048 builder = class_8047.method_48364();

		for (class_8047.class_8049 slot : original.method_48368()) {
			Predicate<class_1799> predicate = slot.comp_1207();
			if (slot.comp_1204() == class_4862.field_41925) {
				predicate = predicate.or(ARSA_BASE_PREDICATE);
			}
			builder.method_48374(slot.comp_1204(), slot.comp_1205(), slot.comp_1206(), predicate);
		}

		class_8047.class_8049 result = original.method_48366();
		builder.method_48373(result.comp_1204(), result.comp_1205(), result.comp_1206());
		cir.setReturnValue(builder.method_48372());
	}

	/**
	 * 允许 shift 点击把合法基底放入锻造台。
	 */
	@Inject(method = "canMoveIntoInputSlots", at = @At("RETURN"), cancellable = true)
	private void arsa$allowBaseShiftClick(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
		if (!cir.getReturnValue() && ARSA_BASE_PREDICATE.test(stack)) {
			cir.setReturnValue(true);
		}
	}
}
