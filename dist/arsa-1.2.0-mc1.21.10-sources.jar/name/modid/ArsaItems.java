package name.modid;

import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class ArsaItems {
	// 1.21.11 要求物品构造时必须带 RegistryKey（Item.Properties#setId），否则运行时 NPE。
	public static final class_1792 ENCHANTMENT_TEMPLATE = new class_1792(
		new class_1792.class_1793()
			.method_63686(class_5321.method_29179(class_7924.field_41197, Arsa.id("enchantment_template")))
			.method_7889(64)
			.method_7894(class_1814.field_8903)
	);

	private ArsaItems() {
	}

	public static void init() {
		class_2378.method_10230(class_7923.field_41178, Arsa.id("enchantment_template"), ENCHANTMENT_TEMPLATE);
	}
}
