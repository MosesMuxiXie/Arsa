package name.modid.template;

import name.modid.ArsaItems;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

/**
 * 附魔模板的核心数据读写与合法性校验。
 * 所有“模板能否应用”的规则都收口在这里，供锻造台配方与 GUI 槽位判定复用。
 */
public final class TemplateEnchantments {
	private TemplateEnchantments() {
	}

	public static boolean isTemplate(class_1799 stack) {
		return stack.method_31574(ArsaItems.ENCHANTMENT_TEMPLATE);
	}

	/** 模板自身的附魔数据（minecraft:enchantments 组件）。 */
	public static class_9304 get(class_1799 stack) {
		return stack.method_58695(class_9334.field_49633, class_9304.field_49385);
	}

	/**
	 * 附魔书 -> 模板；只复制书上的全部附魔（stored_enchantments 由原版助手方法自动处理）。
	 * 不复制附魔书的 repair_cost、名字、Lore 或其他组件，因此新模板的铁砧 penalty 始终为零。
	 */
	public static class_1799 fromBook(class_1799 book) {
		class_1799 template = new class_1799(ArsaItems.ENCHANTMENT_TEMPLATE);
		// 防御性显式移除：模板输出绝不携带输入附魔书累积的铁砧 penalty。
		template.method_57381(class_9334.field_49639);
		class_9304 enchantments = class_1890.method_57532(book);
		if (!enchantments.method_57543()) {
			template.method_57379(class_9334.field_49633, enchantments);
		}
		return template;
	}

	/**
	 * 锻造台基底槽是否允许放入该物品（槽位判定用，比 canApply 宽松）：
	 * 任意非空、且不是附魔书 / 普通书 / 附魔模板。
	 */
	public static boolean isValidBase(class_1799 stack) {
		return !stack.method_7960()
			&& !stack.method_31574(class_1802.field_8598)
			&& !stack.method_31574(class_1802.field_8529)
			&& !isTemplate(stack);
	}

	/**
	 * 严格合法性检查：任一条件不满足即返回 false，锻造台结果槽显示为空。
	 */
	public static boolean canApply(class_1799 template, class_1799 base) {
		if (!isTemplate(template) || !isValidBase(base)) {
			return false;
		}

		class_9304 toAdd = get(template);
		if (toAdd.method_57543()) {
			return false;
		}

		class_9304 existing = base.method_58695(class_9334.field_49633, class_9304.field_49385);

		// 1) 每条附魔必须适用于基底；基底已有同种附魔（不论等级）一律拒绝。
		for (class_6880<class_1887> holder : toAdd.method_57534()) {
			if (!holder.comp_349().method_8192(base)) {
				return false;
			}
			if (existing.method_57536(holder) > 0) {
				return false;
			}
		}

		// 2) 模板内部两两互斥。
		for (class_6880<class_1887> a : toAdd.method_57534()) {
			for (class_6880<class_1887> b : toAdd.method_57534()) {
				if (a != b && !class_1887.method_60033(a, b)) {
					return false;
				}
			}
		}

		// 3) 与基底已有附魔互斥（双向检查，防御性）。
		for (class_6880<class_1887> a : toAdd.method_57534()) {
			for (class_6880<class_1887> b : existing.method_57534()) {
				if (!class_1887.method_60033(a, b) || !class_1887.method_60033(b, a)) {
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * 基底复制品 + 模板附魔合并；名字 / Lore / 耐久 / repair_cost 等组件原样保留。
	 */
	public static class_1799 applyTo(class_1799 template, class_1799 base) {
		class_1799 result = base.method_7972();
		// 锻造台只消耗 1 个基底；若基底是可堆叠的可附魔物品，结果也必须只有 1 个，
		// 否则 base.copy() 会把整组数量带到结果槽，形成物品复制。
		result.method_7939(1);
		class_9304 existing = result.method_58695(class_9334.field_49633, class_9304.field_49385);
		class_9304 toAdd = get(template);
		class_9304.class_9305 mutable = new class_9304.class_9305(existing);

		for (class_6880<class_1887> holder : toAdd.method_57534()) {
			mutable.method_57550(holder, toAdd.method_57536(holder));
		}

		result.method_57379(class_9334.field_49633, mutable.method_57549());
		return result;
	}
}
