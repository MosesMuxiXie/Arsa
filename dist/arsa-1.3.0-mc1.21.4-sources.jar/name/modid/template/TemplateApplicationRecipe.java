package name.modid.template;

import name.modid.ArsaItems;
import name.modid.ArsaRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_7225;
import net.minecraft.class_8059;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9697;
import net.minecraft.class_9887;
import com.mojang.serialization.MapCodec;
import java.util.Optional;

/**
 * 锻造台应用配方：模板槽=附魔模板，基底槽=可附魔物品，材料槽必须为空。
 * 复用原版 RecipeType.SMITHING，失败时 assemble 返回 EMPTY，结果槽即为空。
 */
public class TemplateApplicationRecipe implements class_8059 {
	public static final TemplateApplicationRecipe INSTANCE = new TemplateApplicationRecipe();

	public static final MapCodec<TemplateApplicationRecipe> CODEC = MapCodec.unit(INSTANCE);
	public static final class_9139<class_9129, TemplateApplicationRecipe> STREAM_CODEC = class_9139.method_56431(INSTANCE);

	private TemplateApplicationRecipe() {
	}

	@Override
	public Optional<class_1856> method_64722() {
		return Optional.of(class_1856.method_8101(ArsaItems.ENCHANTMENT_TEMPLATE));
	}

	@Override
	public Optional<class_1856> method_64723() {
		// 槽位插入由 SmithingMenuMixin 放宽到所有合法基底；这里仅提供非空占位原料，
		// 使 RecipeManager 能正常收集 SMITHING_BASE 属性集。
		return Optional.of(class_1856.method_8101(class_1802.field_8687));
	}

	@Override
	public Optional<class_1856> method_64724() {
		// 材料槽必须为空。
		return Optional.empty();
	}

	@Override
	public boolean method_61702(class_9697 input, class_1937 level) {
		return TemplateEnchantments.isTemplate(input.comp_2677())
			&& !TemplateEnchantments.get(input.comp_2677()).method_57543()
			&& TemplateEnchantments.isValidBase(input.comp_2678())
			&& input.comp_2679().method_7960();
	}

	@Override
	public class_1799 assemble(class_9697 input, class_7225.class_7874 registries) {
		class_1799 template = input.comp_2677();
		class_1799 base = input.comp_2678();

		if (!TemplateEnchantments.canApply(template, base)) {
			return class_1799.field_8037;
		}

		return TemplateEnchantments.applyTo(template, base);
	}

	@Override
	public boolean method_8118() {
		return true;
	}

	@Override
	public class_9887 method_61671() {
		return class_9887.field_52597;
	}

	@Override
	public class_1865<TemplateApplicationRecipe> method_8119() {
		return ArsaRecipes.TEMPLATE_APPLICATION;
	}
}
