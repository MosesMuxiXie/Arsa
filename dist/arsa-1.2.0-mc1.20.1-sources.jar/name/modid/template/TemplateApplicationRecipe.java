package name.modid.template;

import name.modid.ArsaItems;
import name.modid.ArsaRecipes;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_8059;

/**
 * 锻造台应用配方：模板槽=附魔模板，基底槽=可附魔物品，材料槽必须为空。
 * 复用原版 RecipeType.SMITHING，失败时 assemble 返回 EMPTY，结果槽即为空。
 */
public class TemplateApplicationRecipe implements class_8059 {
	private final class_2960 id;

	public TemplateApplicationRecipe(class_2960 id) {
		this.id = id;
	}

	@Override
	public class_2960 method_8114() {
		return id;
	}

	@Override
	public boolean method_48453(class_1799 stack) {
		return stack.method_31574(ArsaItems.ENCHANTMENT_TEMPLATE);
	}

	@Override
	public boolean method_48454(class_1799 stack) {
		return TemplateEnchantments.isValidBase(stack);
	}

	@Override
	public boolean method_30029(class_1799 stack) {
		return false;
	}

	@Override
	public boolean method_8115(class_1263 input, class_1937 level) {
		return TemplateEnchantments.isTemplate(input.method_5438(0))
			&& !TemplateEnchantments.get(input.method_5438(0)).isEmpty()
			&& TemplateEnchantments.isValidBase(input.method_5438(1))
			&& input.method_5438(2).method_7960();
	}

	@Override
	public class_1799 method_8116(class_1263 input, class_5455 registries) {
		class_1799 template = input.method_5438(0);
		class_1799 base = input.method_5438(1);

		if (!TemplateEnchantments.canApply(template, base)) {
			return class_1799.field_8037;
		}

		return TemplateEnchantments.applyTo(template, base);
	}

	@Override
	public class_1799 method_8110(class_5455 registries) {
		// 实际结果取决于基底物品及模板携带的附魔，无法静态预览。
		return class_1799.field_8037;
	}

	@Override
	public boolean method_8118() {
		return true;
	}

	@Override
	public class_1865<TemplateApplicationRecipe> method_8119() {
		return ArsaRecipes.TEMPLATE_APPLICATION;
	}
}
