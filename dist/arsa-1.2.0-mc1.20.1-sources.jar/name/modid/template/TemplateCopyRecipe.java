package name.modid.template;

import name.modid.ArsaItems;
import name.modid.ArsaRecipes;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

/**
 * 工作台复制配方：上中=普通书，正中=附魔模板，其余 7 格=绿宝石。
 * 输出 2 个携带完全相同附魔组件的模板。
 */
public class TemplateCopyRecipe extends class_1852 {
	private static final class_1856 BOOK = class_1856.method_8091(class_1802.field_8529);
	private static final class_1856 TEMPLATE = class_1856.method_8091(ArsaItems.ENCHANTMENT_TEMPLATE);
	private static final class_1856 EMERALD = class_1856.method_8091(class_1802.field_8687);

	/**
	 * 3×3 工作台中的行优先原料顺序。PlacementInfo 同时供配方书判定可合成性
	 * 和服务端一键摆放使用，因此必须与 matches 里的坐标严格一致。
	 */
	public TemplateCopyRecipe(class_2960 id) {
		super(id, class_7710.field_40251);
	}

	@Override
	public boolean matches(class_8566 input, class_1937 level) {
		if (input.method_17398() != 3 || input.method_17397() != 3) {
			return false;
		}

		class_1799 book = input.method_5438(1);
		class_1799 template = input.method_5438(4);

		if (!book.method_31574(class_1802.field_8529)) {
			return false;
		}
		if (!TemplateEnchantments.isTemplate(template) || TemplateEnchantments.get(template).isEmpty()) {
			return false;
		}

		for (int x = 0; x < 3; x++) {
			for (int y = 0; y < 3; y++) {
				if ((x == 1 && y == 0) || (x == 1 && y == 1)) {
					continue;
				}
				if (!input.method_5438(x + y * 3).method_31574(class_1802.field_8687)) {
					return false;
				}
			}
		}

		return true;
	}

	@Override
	public class_1799 assemble(class_8566 input, class_5455 registries) {
		class_1799 result = new class_1799(ArsaItems.ENCHANTMENT_TEMPLATE, 2);

		for (int i = 0; i < input.method_5439(); i++) {
			class_1799 stack = input.method_5438(i);
			if (TemplateEnchantments.isTemplate(stack)) {
				class_1890.method_8214(TemplateEnchantments.get(stack), result);
				break;
			}
		}

		return result;
	}

	/**
	 * CustomRecipe 默认是“特殊配方”并且不可摆放，那会让它从原版配方书中消失。
	 * 这个配方有固定的 3×3 外形，所以可以安全提供完整的摆放信息。
	 */
	@Override
	public boolean method_8118() {
		return false;
	}

	@Override
	public boolean method_8113(int width, int height) {
		return width >= 3 && height >= 3;
	}

	@Override
	public class_2371<class_1856> method_8117() {
		class_2371<class_1856> ingredients = class_2371.method_10211();
		ingredients.add(EMERALD);
		ingredients.add(BOOK);
		ingredients.add(EMERALD);
		ingredients.add(EMERALD);
		ingredients.add(TEMPLATE);
		ingredients.add(EMERALD);
		ingredients.add(EMERALD);
		ingredients.add(EMERALD);
		ingredients.add(EMERALD);
		return ingredients;
	}

	@Override
	public class_1799 method_8110(class_5455 registries) {
		return new class_1799(ArsaItems.ENCHANTMENT_TEMPLATE, 2);
	}

	@Override
	public class_1865<TemplateCopyRecipe> method_8119() {
		return ArsaRecipes.TEMPLATE_COPY;
	}
}
