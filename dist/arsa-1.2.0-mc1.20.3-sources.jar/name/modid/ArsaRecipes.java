package name.modid;

import name.modid.template.TemplateApplicationRecipe;
import name.modid.template.TemplateCopyRecipe;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2540;
import net.minecraft.class_7923;
import com.mojang.serialization.Codec;

// 1.21.11 中 RecipeSerializer#streamCodec 已标记弃用，但仍是自定义序列化器必须实现的接口方法。
@SuppressWarnings("deprecation")
public final class ArsaRecipes {
	public static final class_1865<TemplateCopyRecipe> TEMPLATE_COPY = new class_1865<>() {
		@Override
		public Codec<TemplateCopyRecipe> method_53736() {
			return TemplateCopyRecipe.CODEC;
		}

		@Override
		public TemplateCopyRecipe method_8122(class_2540 buffer) {
			return TemplateCopyRecipe.INSTANCE;
		}

		@Override
		public void toNetwork(class_2540 buffer, TemplateCopyRecipe recipe) {
		}
	};

	public static final class_1865<TemplateApplicationRecipe> TEMPLATE_APPLICATION = new class_1865<>() {
		@Override
		public Codec<TemplateApplicationRecipe> method_53736() {
			return TemplateApplicationRecipe.CODEC;
		}

		@Override
		public TemplateApplicationRecipe method_8122(class_2540 buffer) {
			return TemplateApplicationRecipe.INSTANCE;
		}

		@Override
		public void toNetwork(class_2540 buffer, TemplateApplicationRecipe recipe) {
		}
	};

	private ArsaRecipes() {
	}

	public static void init() {
		class_2378.method_10230(class_7923.field_41189, Arsa.id("template_copy"), TEMPLATE_COPY);
		class_2378.method_10230(class_7923.field_41189, Arsa.id("template_application"), TEMPLATE_APPLICATION);
	}
}
