package name.modid.mixin;

import name.modid.template.TemplateEnchantments;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_3914;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_4861;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 铁砧制作附魔模板 + 模板只读。
 * 继承 ItemCombinerMenu（与官方 Fabric API 的 AnvilMenuMixin 同款写法），
 * 直接使用继承来的 inputSlots / resultSlots / broadcastChanges()，
 * 仅对 AnvilMenu 自身的私有字段保留 @Shadow。
 */
@Mixin(class_1706.class)
public abstract class AnvilMenuMixin extends class_4861 {
	@Unique
	private static final int TEMPLATE_LEVEL_COST = 10;

	@Shadow
	private class_3915 cost;

	@Shadow
	private int repairItemCountCost;

	protected AnvilMenuMixin(class_3917<?> type, int syncId, class_1661 playerInventory,
	                         class_3914 context) {
		super(type, syncId, playerInventory, context);
	}

	@Inject(method = "createResult", at = @At("HEAD"), cancellable = true)
	private void arsa$handleTemplateRecipe(CallbackInfo ci) {
		class_1799 left = this.field_22480.method_5438(0);
		class_1799 right = this.field_22480.method_5438(1);

		// 模板只读：禁止再进铁砧合并/改名
		if (TemplateEnchantments.isTemplate(left)) {
			ci.cancel();
			this.field_22479.method_5447(0, class_1799.field_8037);
			this.cost.method_17404(0);
			this.repairItemCountCost = 0;
			this.method_7623();
			return;
		}

		// 制作：附魔书(左) + 绿宝石块(右)
		if (left.method_31574(class_1802.field_8598) && right.method_31574(class_1802.field_8733)) {
			ci.cancel();
			if (class_1890.method_57532(left).method_57543() || right.method_7947() < 9) {
				this.field_22479.method_5447(0, class_1799.field_8037);
				this.cost.method_17404(0);
				this.repairItemCountCost = 0;
			} else {
				this.arsa$setFixedTemplateResult(TemplateEnchantments.fromBook(left));
			}
			this.method_7623();
		}
	}

	/**
	 * 结果刷新后的兜底：即使其他铁砧逻辑在同一轮计算中改写了 cost，
	 * 只要结果仍是附魔模板，就恢复为固定 10 级并清除输出的 repair_cost。
	 */
	@Inject(method = "createResult", at = @At("RETURN"))
	private void arsa$normalizeTemplateResultAfterRefresh(CallbackInfo ci) {
		class_1799 result = this.field_22479.method_5438(0);
		if (TemplateEnchantments.isTemplate(result)) {
			this.arsa$setFixedTemplateResult(result);
		}
	}

	/**
	 * 不让原版 mayPickup 读取任何可能残留的高费用。
	 * 生存只检查是否有固定的 10 级经验，创造模式照常无视经验。
	 */
	@Inject(method = "mayPickup", at = @At("HEAD"), cancellable = true)
	private void arsa$mayPickupTemplateAtFixedCost(class_1657 player, boolean hasStack,
	                                               CallbackInfoReturnable<Boolean> cir) {
		if (hasStack && TemplateEnchantments.isTemplate(this.field_22479.method_5438(0))) {
			this.cost.method_17404(TEMPLATE_LEVEL_COST);
			cir.setReturnValue(player.method_31549().field_7477 || player.field_7520 >= TEMPLATE_LEVEL_COST);
		}
	}

	/** 实际取出前再归一一次，保证原版 onTake 最终只扣 10 级和 9 个绿宝石块。 */
	@Inject(method = "onTake", at = @At("HEAD"))
	private void arsa$normalizeTemplateBeforeTake(class_1657 player, class_1799 stack, CallbackInfo ci) {
		if (TemplateEnchantments.isTemplate(stack)) {
			stack.method_57381(class_9334.field_49639);
			this.cost.method_17404(TEMPLATE_LEVEL_COST);
			this.repairItemCountCost = 9;
		}
	}

	@Unique
	private void arsa$setFixedTemplateResult(class_1799 result) {
		// 模板永不继承附魔书经多次铁砧合并产生的 penalty。
		result.method_57381(class_9334.field_49639);
		this.field_22479.method_5447(0, result);
		this.cost.method_17404(TEMPLATE_LEVEL_COST);
		this.repairItemCountCost = 9;
	}
}
