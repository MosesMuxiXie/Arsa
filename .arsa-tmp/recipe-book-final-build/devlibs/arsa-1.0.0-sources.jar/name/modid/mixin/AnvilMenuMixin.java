package name.modid.mixin;

import name.modid.template.TemplateEnchantments;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.inventory.ItemCombinerMenu;
import net.minecraft.world.inventory.ItemCombinerMenuSlotDefinition;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

/**
 * 铁砧制作附魔模板 + 模板只读。
 * 继承 ItemCombinerMenu（与官方 Fabric API 的 AnvilMenuMixin 同款写法），
 * 直接使用继承来的 inputSlots / resultSlots / broadcastChanges()，
 * 仅对 AnvilMenu 自身的私有字段保留 @Shadow。
 */
@Mixin(AnvilMenu.class)
public abstract class AnvilMenuMixin extends ItemCombinerMenu {
	@Shadow
	private DataSlot cost;

	@Shadow
	private int repairItemCountCost;

	protected AnvilMenuMixin(MenuType<?> type, int syncId, Inventory playerInventory,
	                         ContainerLevelAccess context, ItemCombinerMenuSlotDefinition forgingSlotsManager) {
		super(type, syncId, playerInventory, context, forgingSlotsManager);
	}

	@Inject(method = "createResult", at = @At("HEAD"), cancellable = true)
	private void arsa$handleTemplateRecipe(CallbackInfo ci) {
		ItemStack left = this.inputSlots.getItem(0);
		ItemStack right = this.inputSlots.getItem(1);

		// 模板只读：禁止再进铁砧合并/改名
		if (TemplateEnchantments.isTemplate(left)) {
			ci.cancel();
			this.resultSlots.setItem(0, ItemStack.EMPTY);
			this.cost.set(0);
			this.repairItemCountCost = 0;
			this.broadcastChanges();
			return;
		}

		// 制作：附魔书(左) + 绿宝石块(右)
		if (left.is(Items.ENCHANTED_BOOK) && right.is(Items.EMERALD_BLOCK)) {
			ci.cancel();
			if (EnchantmentHelper.getEnchantmentsForCrafting(left).isEmpty() || right.getCount() < 9) {
				this.resultSlots.setItem(0, ItemStack.EMPTY);
				this.cost.set(0);
				this.repairItemCountCost = 0;
			} else {
				this.resultSlots.setItem(0, TemplateEnchantments.fromBook(left));
				this.cost.set(40);
				// 取出时只消耗 9 个绿宝石块，剩余保留
				this.repairItemCountCost = 9;
			}
			this.broadcastChanges();
		}
	}
}
