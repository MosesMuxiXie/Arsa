package name.modid.client.mixin;

import name.modid.ArsaItems;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.screens.inventory.AnvilScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AnvilMenu;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 1.21.11 原版 AnvilScreen 在 cost >= 40 且非创造时完全不绘制费用文本
 * （原版此路径结果必为空）。附魔模板配方费用恰好是 40，
 * 生存玩家会看到成品却看不到费用。这里在 renderLabels 末尾补画
 * "附魔花费: 40"（买不起时红色）；创造模式原版已正常绘制，无需处理。
 * 继承 AbstractContainerScreen<AnvilMenu>，menu/imageWidth/font/minecraft 全部直接继承，无需 @Shadow。
 */
@Mixin(AnvilScreen.class)
public abstract class AnvilScreenMixin extends AbstractContainerScreen<AnvilMenu> {
	protected AnvilScreenMixin(AnvilMenu menu, Inventory playerInventory, Component title) {
		super(menu, playerInventory, title);
	}

	@Inject(method = "renderLabels", at = @At("RETURN"))
	private void arsa$drawTemplateCost(GuiGraphics guiGraphics, int mouseX, int mouseY, CallbackInfo ci) {
		if (this.minecraft.player == null || this.minecraft.player.getAbilities().instabuild) {
			return; // 创造模式原版已正常绘制费用
		}
		AnvilMenu anvilMenu = this.menu;
		if (anvilMenu.getCost() != 40
			|| !anvilMenu.getSlot(AnvilMenu.RESULT_SLOT).hasItem()
			|| !anvilMenu.getSlot(AnvilMenu.RESULT_SLOT).getItem().is(ArsaItems.ENCHANTMENT_TEMPLATE)) {
			return;
		}
		Component cost = Component.translatable("container.repair.cost", 40);
		Font font = this.font;
		int x = this.imageWidth - 8 - font.width(cost) - 2;
		guiGraphics.fill(x - 2, 67, this.imageWidth - 8, 79, 0x4F000000);
		guiGraphics.drawString(font, cost, x, 69,
			anvilMenu.getSlot(AnvilMenu.RESULT_SLOT).mayPickup(this.minecraft.player) ? 8453920 : 16736352);
	}
}
