package name.modid;

import name.modid.template.TemplateApplicationRecipe;
import name.modid.template.TemplateCopyRecipe;

import com.mojang.serialization.MapCodec;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.crafting.RecipeSerializer;

public final class ArsaRecipes {
	public static final RecipeSerializer<TemplateCopyRecipe> TEMPLATE_COPY = new RecipeSerializer<>() {
		@Override
		public MapCodec<TemplateCopyRecipe> codec() {
			return TemplateCopyRecipe.CODEC;
		}

		@Override
		public StreamCodec<RegistryFriendlyByteBuf, TemplateCopyRecipe> streamCodec() {
			return TemplateCopyRecipe.STREAM_CODEC;
		}
	};

	public static final RecipeSerializer<TemplateApplicationRecipe> TEMPLATE_APPLICATION = new RecipeSerializer<>() {
		@Override
		public MapCodec<TemplateApplicationRecipe> codec() {
			return TemplateApplicationRecipe.CODEC;
		}

		@Override
		public StreamCodec<RegistryFriendlyByteBuf, TemplateApplicationRecipe> streamCodec() {
			return TemplateApplicationRecipe.STREAM_CODEC;
		}
	};

	private ArsaRecipes() {
	}

	public static void init() {
		Registry.register(BuiltInRegistries.RECIPE_SERIALIZER, Arsa.id("template_copy"), TEMPLATE_COPY);
		Registry.register(BuiltInRegistries.RECIPE_SERIALIZER, Arsa.id("template_application"), TEMPLATE_APPLICATION);
	}
}
