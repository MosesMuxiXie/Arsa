package name.modid.template;

import name.modid.ArsaItems;
import name.modid.ArsaRecipes;
import net.minecraft.class_10295;
import net.minecraft.class_10300;
import net.minecraft.class_10302;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_7225;
import net.minecraft.class_7710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9334;
import net.minecraft.class_9694;
import net.minecraft.class_9887;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.Optional;

/**
 * 工作台复制配方：上中=普通书，正中=附魔模板，其余 7 格=绿宝石。
 * 输出 2 个携带完全相同附魔组件的模板。
 */
public class TemplateCopyRecipe extends class_1852 {
	public static final TemplateCopyRecipe INSTANCE = new TemplateCopyRecipe();

	public static final MapCodec<TemplateCopyRecipe> CODEC = MapCodec.unit(INSTANCE);
	public static final class_9139<class_9129, TemplateCopyRecipe> STREAM_CODEC = class_9139.method_56431(INSTANCE);

	private static final class_1856 BOOK = class_1856.method_8101(class_1802.field_8529);
	private static final class_1856 TEMPLATE = class_1856.method_8101(ArsaItems.ENCHANTMENT_TEMPLATE);
	private static final class_1856 EMERALD = class_1856.method_8101(class_1802.field_8687);

	/**
	 * 3×3 工作台中的行优先原料顺序。PlacementInfo 同时供配方书判定可合成性
	 * 和服务端一键摆放使用，因此必须与 matches 里的坐标严格一致。
	 */
	private static final List<Optional<class_1856>> PATTERN_INGREDIENTS = List.of(
		Optional.of(EMERALD), Optional.of(BOOK), Optional.of(EMERALD),
		Optional.of(EMERALD), Optional.of(TEMPLATE), Optional.of(EMERALD),
		Optional.of(EMERALD), Optional.of(EMERALD), Optional.of(EMERALD)
	);
	private static final class_9887 PLACEMENT_INFO = class_9887.method_61683(PATTERN_INGREDIENTS);

	private TemplateCopyRecipe() {
		super(class_7710.field_40251);
	}

	@Override
	public boolean matches(class_9694 input, class_1937 level) {
		if (input.method_59991() != 3 || input.method_59992() != 3) {
			return false;
		}

		class_1799 book = input.method_59985(1, 0);
		class_1799 template = input.method_59985(1, 1);

		if (!book.method_31574(class_1802.field_8529)) {
			return false;
		}
		if (!TemplateEnchantments.isTemplate(template) || TemplateEnchantments.get(template).method_57543()) {
			return false;
		}

		for (int x = 0; x < 3; x++) {
			for (int y = 0; y < 3; y++) {
				if ((x == 1 && y == 0) || (x == 1 && y == 1)) {
					continue;
				}
				if (!input.method_59985(x, y).method_31574(class_1802.field_8687)) {
					return false;
				}
			}
		}

		return true;
	}

	@Override
	public class_1799 assemble(class_9694 input, class_7225.class_7874 registries) {
		class_1799 result = new class_1799(ArsaItems.ENCHANTMENT_TEMPLATE, 2);

		for (int i = 0; i < input.method_59983(); i++) {
			class_1799 stack = input.method_59984(i);
			if (TemplateEnchantments.isTemplate(stack)) {
				result.method_57379(class_9334.field_49633, TemplateEnchantments.get(stack));
				break;
			}
		}

		return result;
	}

	/**
	 * CustomRecipe 默认是“特殊配方”并且不可摆放，那会让它从原版配方书中消失。
	 * 这个配方有固定的 3×3 外形，所以可以安全提供完整的摆放信息。
	 */
	@Override
	public boolean method_8118() {
		return false;
	}

	@Override
	public class_9887 method_61671() {
		return PLACEMENT_INFO;
	}

	@Override
	public List<class_10295> method_64664() {
		List<class_10302> ingredients = PATTERN_INGREDIENTS.stream()
			.map(ingredient -> ingredient.map(class_1856::method_64673).orElse(class_10302.class_10305.field_54681))
			.toList();

		return List.of(new class_10300(
			3,
			3,
			ingredients,
			new class_10302.class_10307(new class_1799(ArsaItems.ENCHANTMENT_TEMPLATE, 2)),
			new class_10302.class_10306(class_1802.field_8465)
		));
	}

	@Override
	public class_1865<TemplateCopyRecipe> method_8119() {
		return ArsaRecipes.TEMPLATE_COPY;
	}
}
