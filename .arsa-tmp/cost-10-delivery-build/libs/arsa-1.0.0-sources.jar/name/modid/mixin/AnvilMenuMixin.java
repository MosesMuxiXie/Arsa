package name.modid.mixin;

import name.modid.template.TemplateEnchantments;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1890;
import net.minecraft.class_3914;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_4861;
import net.minecraft.class_8047;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 铁砧制作附魔模板 + 模板只读。
 * 继承 ItemCombinerMenu（与官方 Fabric API 的 AnvilMenuMixin 同款写法），
 * 直接使用继承来的 inputSlots / resultSlots / broadcastChanges()，
 * 仅对 AnvilMenu 自身的私有字段保留 @Shadow。
 */
@Mixin(class_1706.class)
public abstract class AnvilMenuMixin extends class_4861 {
	private static final int TEMPLATE_LEVEL_COST = 10;

	@Shadow
	private class_3915 cost;

	@Shadow
	private int repairItemCountCost;

	protected AnvilMenuMixin(class_3917<?> type, int syncId, class_1661 playerInventory,
	                         class_3914 context, class_8047 forgingSlotsManager) {
		super(type, syncId, playerInventory, context, forgingSlotsManager);
	}

	@Inject(method = "createResult", at = @At("HEAD"), cancellable = true)
	private void arsa$handleTemplateRecipe(CallbackInfo ci) {
		class_1799 left = this.field_22480.method_5438(0);
		class_1799 right = this.field_22480.method_5438(1);

		// 模板只读：禁止再进铁砧合并/改名
		if (TemplateEnchantments.isTemplate(left)) {
			ci.cancel();
			this.field_22479.method_5447(0, class_1799.field_8037);
			this.cost.method_17404(0);
			this.repairItemCountCost = 0;
			this.method_7623();
			return;
		}

		// 制作：附魔书(左) + 绿宝石块(右)
		if (left.method_31574(class_1802.field_8598) && right.method_31574(class_1802.field_8733)) {
			ci.cancel();
			if (class_1890.method_57532(left).method_57543() || right.method_7947() < 9) {
				this.field_22479.method_5447(0, class_1799.field_8037);
				this.cost.method_17404(0);
				this.repairItemCountCost = 0;
			} else {
				this.field_22479.method_5447(0, TemplateEnchantments.fromBook(left));
				// 始终固定为 10 级：不读取附魔数量、等级或附魔书的铁砧 penalty。
				this.cost.method_17404(TEMPLATE_LEVEL_COST);
				// 取出时只消耗 9 个绿宝石块，剩余保留
				this.repairItemCountCost = 9;
			}
			this.method_7623();
		}
	}
}
