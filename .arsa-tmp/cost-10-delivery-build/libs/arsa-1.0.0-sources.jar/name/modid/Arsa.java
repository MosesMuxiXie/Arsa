package name.modid;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Arsa implements ModInitializer {
	public static final String MOD_ID = "arsa";

	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		ArsaItems.init();
		ArsaRecipes.init();

		ItemGroupEvents.modifyEntriesEvent(class_7706.field_41062).register(entries ->
			entries.addAfter(class_1802.field_41946, ArsaItems.ENCHANTMENT_TEMPLATE)
		);

		LOGGER.info("Arsa enchantment template initialized.");
	}

	public static class_2960 id(String path) {
		return class_2960.method_60655(MOD_ID, path);
	}
}
