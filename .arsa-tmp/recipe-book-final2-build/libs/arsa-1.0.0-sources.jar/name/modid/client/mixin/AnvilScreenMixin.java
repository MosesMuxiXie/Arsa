package name.modid.client.mixin;

import name.modid.ArsaItems;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_471;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 1.21.11 原版 AnvilScreen 在 cost >= 40 且非创造时完全不绘制费用文本
 * （原版此路径结果必为空）。附魔模板配方费用恰好是 40，
 * 生存玩家会看到成品却看不到费用。这里在 renderLabels 末尾补画
 * "附魔花费: 40"（买不起时红色）；创造模式原版已正常绘制，无需处理。
 * 继承 AbstractContainerScreen<AnvilMenu>，menu/imageWidth/font/minecraft 全部直接继承，无需 @Shadow。
 */
@Mixin(class_471.class)
public abstract class AnvilScreenMixin extends class_465<class_1706> {
	protected AnvilScreenMixin(class_1706 menu, class_1661 playerInventory, class_2561 title) {
		super(menu, playerInventory, title);
	}

	@Inject(method = "renderLabels", at = @At("RETURN"))
	private void arsa$drawTemplateCost(class_332 guiGraphics, int mouseX, int mouseY, CallbackInfo ci) {
		if (this.field_22787.field_1724 == null || this.field_22787.field_1724.method_31549().field_7477) {
			return; // 创造模式原版已正常绘制费用
		}
		class_1706 anvilMenu = this.field_2797;
		if (anvilMenu.method_17369() != 40
			|| !anvilMenu.method_7611(class_1706.field_41900).method_7681()
			|| !anvilMenu.method_7611(class_1706.field_41900).method_7677().method_31574(ArsaItems.ENCHANTMENT_TEMPLATE)) {
			return;
		}
		class_2561 cost = class_2561.method_43469("container.repair.cost", 40);
		class_327 font = this.field_22793;
		int x = this.field_2792 - 8 - font.method_27525(cost) - 2;
		guiGraphics.method_25294(x - 2, 67, this.field_2792 - 8, 79, 0x4F000000);
		guiGraphics.method_27535(font, cost, x, 69,
			anvilMenu.method_7611(class_1706.field_41900).method_7674(this.field_22787.field_1724) ? 8453920 : 16736352);
	}
}
